## BACA DULU BANG

> **Warning**: Sc nya gk support termux. [`Klik disini untuk download sc yg support termux`](https://github.com/zeeone-ofc/Haruka-Md#For-Termux)

-----------------------------------------------------

<p align="center">
<img src="https://github.com/zeeone-ofc/Haruka-Md/blob/v1/media/Haruka.jpg" alt="ALPHA BOT" width="100"/>


</p>
<p align="center">
<a href="#"><img title="HARUKA MULTI DEVICE" src="https://img.shields.io/badge/HARUKA MULTI DEVICE-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/zeeone-ofc/Haruka-Md"><img title="Owner" src="https://img.shields.io/badge/Recode-ZeeoneOfc-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/zeeone-ofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/zeeone-ofc?color=red&style=flat-square"></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zeeone-ofc/Haruka-Md?color=blue&style=flat-square"></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/zeeone-ofc/Haruka-Md?color=red&style=flat-square"></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zeeone-ofc/Haruka-Md?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md/"><img title="Size" src="https://img.shields.io/github/repo-size/zeeone-ofc/Haruka-Md?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fzeeone-ofc%2FHaruka-Md&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/zeeone-ofc/Haruka-Md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>

<p align="center">
  <a href="https://github.com/zeeone-ofc/Haruka-Md#requirements">Requirements</a> •
  <a href="https://github.com/zeeone-ofc/Haruka-Md#instalasi">Installation</a> •
  <a href="https://github.com/zeeone-ofc/Haruka-Md#thanks-to">Thanks to</a> •
  <a href="https://github.com/zeeone-ofc/Haruka-Md#Official-Group"> Official Group Bot</a> •
  <a href="https://github.com/zeeone-ofc/Haruka-Md#donate">Donate</a>
</p>
</div>


---

# Instalasi
## FOR REPLIT USER
[![Run on Repl.it](https://repl.it/badge/github/zeeone-ofc/Haruka-Md)](https://repl.it/github/zeeone-ofc/Haruka-Md)

[`Click Here For Tutorial`](https://youtu.be/jom_scHK09c)<br>

----------

<p align="center">
  <a href="https://youtu.be/jom_scHK09c"><img src="https://telegra.ph/file/eb8dbe898ed8f9c32f013.jpg" />
</p>

## FOR RAILWAY USER 

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https%3A%2F%2Fgithub.com%2Fzeeone-ofc%2FAlphabot-Md)

[`Click Here For Tutorial`](https://youtu.be/BqRauxohbLg)<br>

----------

<p align="center">
  <a href="https://youtu.be/BqRauxohbLg"><img src="https://telegra.ph/file/ba58c4ad1b43bc285f16b.jpg" />
</p>

## For Termux
- [Download script MediaFire](https://youtu.be/H28_Yf0rDjE)

<p align="center">
<a href="https://youtu.be/H28_Yf0rDjE"><img src="https://telegra.ph/file/7ad8863608d7abffdec01.jpg" />
</p>

## Edit Owner 

<details>
    <summary> <b>Edit Owner Config.json</b></summary><br/>

```ts
{
    "ownerNumber": ["622150996855@s.whatsapp.net","622150996855@s.whatsapp.net"],
    "ownerName": "ᴹᴿ᭄ ZeeoneOfcོ ×፝֟͜×",
    "instagram" : "https://instagram.com/zeeoneofc",
    "botName": "Haruka-Mdོ ",
    "footer": "api.zeeoneofc.xyz",
    "sessionName": "session",
    "pathimg": "./media/Haruka.jpg",
    "BotKey": "Gsyt6jRJ",
    "auto_welcomeMsg": true,
    "auto_leaveMsg": true,    
    "autobio": true,
    "anticall": true,
    "autorespond": false,
    "autoblok212": true,
    "autoread": true,
    "gamewaktu": 90,
    "limitCount": 25,
    "gcount": {
        "prem": 1000,
        "user": 15
    }
}
```

## Donate
- [Saweria](https://saweria.co/zeeoneofc)
- [Dana](https://j.top4top.io/p_20532posd1.jpg)
- [Ovo](https://h.top4top.io/p_2053vk0uw1.jpg)

# Official Group
- [Group 1](https://chat.whatsapp.com/EU890BcXjyBDkNaUT5WmYV)
- [Group 2](https://chat.whatsapp.com/E8NExJwIbhBJYzssfqJNsE)
- [Group 3](https://chat.whatsapp.com/KCSqHTky1apG7ApePsfiPy)
- [Group 4](https://chat.whatsapp.com/KwmvHr7VMFj7r5ry9xmMsU)
- [Group 5](https://chat.whatsapp.com/ELa7GhU0sP4EvXcVimQYtz)

